#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
position = []
unc = [0 for i in range(0,100)]
ra = [0 for i in range(0,100)]
rr = [0 for i in range(0,100)]
t = 0
# we need to import python modules from the $SUMO_HOME/tools directory
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
    sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
    from sumolib import checkBinary
except ImportError:
    sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
    #initialize variables
    step = 0
    q = 0
    x = 1
    y = 0
    LastVeh = []
    b = 0
    ab = 0

    for i in range(750):
        crash_pos.append([-1,0,-1])    #[vehid,0:no crash 1:crash,verifier1]  
        warning.append([-1,0])

    for i in range(100):
        speed.append(-1)
        detected_flag.append(0)
        edge.append("-1")
        position.append([-1,-1])


 #   """execute the TraCI control loop"""
    traci.init(PORT)

    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
        NewVeh = traci.vehicle.getIDList()
        DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
        ThreadNum = len(DecVeh)

        print "step: ",step 

        if(step >= 50):
        	#for each vehicle
            for i in range(100):
                if(str(i) in NewVeh):
                    speed[i] = traci.vehicle.getSpeed(str(i))
                    position.insert(i,traci.vehicle.getPosition(str(i)))
                    edge[i] = traci.vehicle.getRoadID(str(i))
                else:
                    speed[i] = -1
                    position.insert(i,[-1,-1])
                    edge[i] = "-1"
                TmpPos = position[i]
    
            #if a car is in an accident ,this defines its behavior
         	y = len(NewVeh)
         	
                if(speed[i] < 0.1 and TmpPos[0] > 10 and i != 0):
                    if(crash_pos[int(TmpPos[0])] == [-1,0,-1]):
                        if (unc[i] == 0):
                        	x += 1
                        	unc[i] = 1

                        crash_pos[int(TmpPos[0])] = [i,1,-1]
                        print i,"crash",TmpPos
                        q = q + 1

                    elif(crash_pos[int(TmpPos[0])][2] != -1):
                        print "verified,send warning"
                        warning[int(TmpPos[0])] = [i,1]
   

                if(speed[i] < 0.1 and TmpPos[0] > 10 and i == 0 ):
                    if(crash_pos[int(TmpPos[0])] == [-1,0,-1]):
                        crash_pos[int(TmpPos[0])] = [i,0,-1]
                        print i,"crash",TmpPos
                        q = q + 1


            #detect(10 meters) and verify
                if(TmpPos[0]!= -1 and TmpPos[0] < 710):
                    for j in range(int(TmpPos[0])+40,int(TmpPos[0]),-1):
                        if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
                            crash_pos[j][1] = 1
                            crash_pos[j][2] = i                                        
                        elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh):
                            if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1 ):
                                print i,"detected",crash_pos[j][0]
                                print "qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq",q
                                if (crash_pos[j][2] == -1):
                                	crash_pos[j][2] = 1
                                	print i, "verified", j                             
                                if(q > 5):  
                                    if((float(x) / float(x)) > 0.7):
                                        r = random.randint(0, 9)                                            #TS[5] 50% trusted
                                        if(r < 8):                         #CDPD[5,0.7]
                                            if(edge[i] == "1to2"):
                                                traci.vehicle.setRoute(str(i),["1to2","2to4"])
                                                print traci.vehicle.getRoute(str(i))
                                                print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
                                                print"*******************************************",q  
                                            elif(edge[i] == "2_1"):
                                                traci.vehicle.setRoute(str(i),["2_1","2to4"])
                            
                            elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
                                crash_pos[j] = [-1,0,-1]

                                x -= 1

                                print x

                        		
                        elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
                            crash_pos[j] = [-1,0,-1]

            #receive warningy(100 meters) and verify   the range can be changed
                if (ra[i] == 0):
                    r = random.randint(0, 9)
                    rr[i] = r
                    ra[i] = 1
                else:
                    r = rr[i]

                if(TmpPos[0] < 450):
                    MaxRange = int(TmpPos[0])+300
                else:
                    MaxRange = 749
                if(TmpPos[0]!= -1):
	            for j in range(MaxRange,int(TmpPos[0]),-1):
	                if(warning[j][1] == 1 and str(warning[j][0]) in NewVeh):
                            if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1 ):
	                        #print i,"warning received"
                                if(q > 5):  
                                    if((float(x) / float(x)) > 0.7):                         #CDPD[5,0.7]
                                        if (r < 8):                                    
                                            if(edge[i] == "1to2"):
                                                traci.vehicle.setRoute(str(i),["1to2","2to4"])
                                                print traci.vehicle.getRoute(str(i))
                                                print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
                                                print"*******************************************",q  
                                            elif(edge[i] == "2_1"):
                                                traci.vehicle.setRoute(str(i),["2_1","2to4"])
                               
                    	elif(str(warning[j][0]) not in NewVeh):
                       		warning[j] = [-1,0]
        
        step = step + 1

        if(step == 521):
            break;
        LastVeh = NewVeh
    
    sys.stdout.flush()
    traci.close()



def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options



# this is the main entry point of this script
if __name__ == "__main__":
    options = get_options()

    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
    run()
    sumoProcess.wait()
