import os, sys
import optparse
import subprocess
import random
import threading
import time
import math


def generate_routefile():
    random.seed(48) # make tests reproducible
    N = 106 # number of time steps

    with open("hello.rou.xml", "w") as routes:
        print >> routes, """<routes>
  	<vType accel="1.0" decel="5.0" id="Car" length="4.5" minGap="2.0" maxSpeed="50.0" sigma="0" />

        <route id="route0" edges="1to2 2to3" />
  	<route id="route1" edges="1to2 2to4" />"""
        lastVeh = 0
        vehNr = 0
        for i in range(N):
            a = random.uniform(0,9)
            if (vehNr == 0):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '         <stop lane="2to3_0" endPos="100" duration="55"/>'
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue           
          
            elif (vehNr == 1):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue           
          
            elif (vehNr == 2):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue           
            elif (vehNr == 3):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue           
          
            elif (vehNr == 4):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue          

            elif (vehNr == 5):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue           

            elif a < 8:
                print >> routes, '    <vehicle id="%i" type="Car" route="route0" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
            
            elif a >= 8:
                print >> routes, '    <vehicle id="%i" type="Car" route="route1" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
        print >> routes, "</routes>"



if __name__ == "__main__":
    # first, generate the route file for this simulation
    generate_routefile()

