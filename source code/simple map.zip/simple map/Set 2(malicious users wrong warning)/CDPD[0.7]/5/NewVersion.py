#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
route = []
route = []
position = []
ra = [0 for i in range(0,100)]
rr = [0 for i in range(0,100)]
t = 0
aba = [0 for i in range(0,100)]
victim_array = [0 for i in range(0,100)]

# we need to import python modules from the $SUMO_HOME/tools directory
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
    sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
    from sumolib import checkBinary
except ImportError:
    sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
    #initialize variables
    step = 0
    LastVeh = []
    mini = 0
    q = 5                                    # q if the parameter of the number of malicious users.
    victim = 0

    for i in range(750):
        crash_pos.append([-1,0,-1])    #[vehid,0:no crash 1:crash,verifier1]  
        warning.append([-1,0])

    for i in range(100):
        speed.append(-1)
        detected_flag.append(0)
        edge.append("-1")
        route.append("-1")
        position.append([-1,-1])

 #   """execute the TraCI control loop"""
    traci.init(PORT)

    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
        NewVeh = traci.vehicle.getIDList()
        DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
        ThreadNum = len(DecVeh)

        print "step: ",step 
        if(step >= 50):
        	#for each vehicle
            for i in range(100):
                if(str(i) in NewVeh):
                    speed[i] = traci.vehicle.getSpeed(str(i))
                    position.insert(i,traci.vehicle.getPosition(str(i)))
                    edge[i] = traci.vehicle.getRoadID(str(i))
                    route[i] = traci.vehicle.getRoute(str(i))
                else:
                    speed[i] = -1
                    position.insert(i,[-1,-1])
                    edge[i] = "-1"
                    route[i] = "-1"

                TmpPos = position[i]

            #detect(10 meters) and verify
                if(TmpPos[0]!= -1 and TmpPos[0] < 710 and str(i) in NewVeh):
                    for j in range(int(TmpPos[0])+40 and int(TmpPos[0])):
                        if(q >= 5):  
                            if (((q - mini) * 100 / q) > 70 ):                         #CDPD[5,0.7]
                                #print "method get in the loop "
                                if (ra[i] == 0):
                                    r = random.randint(0, 9)
                                    rr[i] = r
                                    ra[i] = 1
                                else:
                                    r = rr[i]  
                                if(r < 8):
                                    #print "New vehicles trust the warning message and turn into the passway"
                                    if(edge[i] == "1to2"):
                                        traci.vehicle.setRoute(str(i),["1to2","2to4"])
                                    elif(edge[i] == "2_1"):
                                        traci.vehicle.setRoute(str(i),["2_1","2to4"])
                                    if(victim_array[i] == 0):
                                        victim = victim + 1
                                        victim_array[i] = 1
                                else:
                                    print "iiiiiiiiiiiiiiiiiiiiiiiiiiii", i
                        if(route[i] == ["1to2","2to3"] and aba[i] == 0):
                            mini = mini + 1
                            aba[i] = 1
                        elif(route[i] == ["2_1","2to3"] and aba[i] == 0):
                            mini = mini + 1
                            aba[i] = 1 
                    if(q == mini):   
                        print "victimvictimvictimvictimvictimvictimvictimvictimvictim",victim
          
            #receive warningy(100 meters) and verify   the range can be changed
                if(TmpPos[0] < 450 and str(i) in NewVeh):
                    MaxRange = int(TmpPos[0])+300
                else:
                    MaxRange = 749
                if(TmpPos[0]!= -1 and str(i) in NewVeh):
                    if(q >= 5):  
                        if (((q - mini) * 100 / q) > 70):                         #CDPD[5,0.7]
                            #print "method get in the loop "
                            if (ra[i] == 0):
                                r = random.randint(0, 9)
                                rr[i] = r
                                ra[i] = 1
                            else:
                                r = rr[i]
                            if(r < 8):
                                #print "New vehicles trust the warning message and turn into the passway"
                                if(edge[i] == "1to2"):
                                    traci.vehicle.setRoute(str(i),["1to2","2to4"])
                                elif(edge[i] == "2_1"):
                                    traci.vehicle.setRoute(str(i),["2_1","2to4"])
                                if(victim_array[i] == 0):
                                    victim = victim + 1
                                    victim_array[i] = 1
                            else:
                                print "iiiiiiiiiiiiiiiiiiiiiiiiiiii", i


                    if(route[i] == ["1to2","2to3"] and aba[i] == 0):
                        mini = mini + 1
                        aba[i] = 1
                    elif(route[i] == ["2_1","2to3"] and aba[i] == 0):
                        mini = mini + 1
                        aba[i] = 1
                if(q == mini):   
                    print "victimvictimvictimvictimvictimvictimvictimvictim",victim
        
        step = step + 1

        if(step == 550):
            break;
        LastVeh = NewVeh
    
    sys.stdout.flush()
    traci.close()


def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options



# this is the main entry point of this script
if __name__ == "__main__":
    options = get_options()

    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
    run()
    sumoProcess.wait()
