#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
position = []
Route = [-2 for i in range(0,5050)]
Threshold = [-1 for i in range(0,7500)]
checkRoute = [-1 for i in range(0,200)]
ra = [0 for i in range(0,5050)]
rr = [0 for i in range(0,5050)]
t = 0
firstVID=[-1 for i in range(1)]
firstVAppeared=[-1 for i in range(1)]
checkedRoute = [0 for i in range(0,5050)]
getRouteID = []
crashedVeh = [0 for i in range(0,200)]
collisionTeam = int(sys.argv[1]) #[0-10] only, min. 4-->TS[3], min. 6-->TS[5], min. 9-->TS[8]
#(TS[3],TS[5],TS[8],PTS[3,5,8])
trustMethod = "CDPD[0.9]"
changedRouteVictim = [0 for i in range(0,5050)]
changedRouteFirstBeneficary = [-1 for i in range(0,9)]
posCount = [-1 for i in range(0,9)]
negCount = [-1 for i in range(0,9)]


# we need to import python modules from the $SUMO_HOME/tools directory
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
	#initialize variables
	step = 0
	LastVeh = []
	b = 0
	crashedV=0
	changedRouteVictimCount = 0

	for i in range(7500):#max 750 road position
		crash_pos.append([-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3,verifier4,verifier5,verifier6,verifier7,verifier8,verifier9,verifier10,Route[i]] 
		warning.append([-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]) #[VehID,state(0/1),vehDeductionIDx10]

	for i in range(5050):									#max 5500 vehicles
		speed.append(-1)
		detected_flag.append(0)
		edge.append("-1")
		position.append([-1,-1])
		getRouteID.append("-1")

	#"""execute the TraCI control loop"""
	traci.init(PORT)

	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
		NewVeh = traci.vehicle.getIDList()
		DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
		ThreadNum = len(DecVeh)

		if (step == 0):
			for i in range(1000,1010):
				Route[i] = 4
				if (i >= 1010 - collisionTeam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"5697769#2", pos=(200-(i-1000)), laneIndex = 0, duration=2**31 - 1, flags=3, startPos=0, until=-1)
		
		if (step == 4):
			for i in range(2000,2010):
				Route[i] = 7
				if (i >= 2010 - collisionTeam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"5697974#1", pos=(120-(i-2000)), laneIndex = 0, duration=2**31 - 1, flags=3, startPos=0, until=-1)
		
		if (step == 80):
			for i in range(3000,3010):
				Route[i] = 8
				if (i >= 3010 - collisionTeam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"5699670#2", pos=(200-(i-3000)), laneIndex = 0, duration=2**31 - 1, flags=3, startPos=0, until=-1)
		
		if (step == 120):
			for i in range(4000,4010):
				Route[i] = 0
				if (i >= 4010 - collisionTeam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"120245128#1", pos=(200-(i-4000)), laneIndex = 0, duration=2**31 - 1, flags=3, startPos=0, until=-1)
		
		if (step == 180):
			for i in range(5000,5010):
				Route[i] = 2
				if (i >= 5010 - collisionTeam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"274840498", pos=(200-(i-5000)), laneIndex = 0, duration=2**31 - 1, flags=3, startPos=0, until=-1)
		
		if(step >= 10):
		#-------------------collision team---------------
			for i in range(1000,5050):
				if((i >= 1010 - collisionTeam and i <= 1009) or (i >= 2010 - collisionTeam and i <= 2009) or (i >= 3010 - collisionTeam and i <= 3009) or (i >= 4010 - collisionTeam and i <= 4009) or (i >= 5010 - collisionTeam and i <= 5009)):
					TmpPos = inputVehInfo (i, NewVeh);			
					#checking collision team's speed. yes if it stops
					if(speed[i] < 0.1 and TmpPos[0] > 10  and (edge[i] == "5697769#2" or edge[i] == "120245128#1" or edge[i] == "5699670#2" or edge[i] == "274840498" or edge[i] == "5697974#1")):
						if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]):
							#print "collisuon team crashs = ",i
							crash_pos[int(TmpPos[0])][0] = i
							crash_pos[int(TmpPos[0])][1] = 1
							crash_pos[int(TmpPos[0])][12] = Route[i]
						#ensure one VehID can generates once only, at least 5 to generate warning msg
						if(crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][5] != -1 and crash_pos[int(TmpPos[0])][12] == Route[i]):
							if (warning[int(TmpPos[0])][0] != i): 
								#print i, " verified,send warning - CDPD min 5"
								warning[int(TmpPos[0])][0] = i #record generator's VehID
								warning[int(TmpPos[0])][1] = 1 #turn state to valid 
								warning[int(TmpPos[0])][12] = Route[i]
					if(TmpPos[0]!= -1 and TmpPos[0] < 7640 and (edge[i] == "5697769#2" or edge[i] == "120245128#1" or edge[i] == "5699670#2" or edge[i] == "274840498" or edge[i] == "5697974#1")):
						for j in range(int(TmpPos[0]) + 40,int(TmpPos[0]),-1):
							#record j's place as crash point, let i be the 1st one finds it
							if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
								crash_pos[j][1] = 1
								crash_pos[j][2] = i    
								crash_pos[j][12] =  Route[i]                                      
							#if j's place is crash point 
							elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh and crash_pos[j][12] == Route[i]):
								# if j is stopped
								if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1):
									#print "Vehicle ID",i,"edge:",edge[i]
									#it is valid, add itself (i) into one of the verifiers
									if(i not in [crash_pos[j][2],crash_pos[j][3],crash_pos[j][4],crash_pos[j][5],crash_pos[j][6],crash_pos[j][7],crash_pos[j][8],crash_pos[j][9],crash_pos[j][10],crash_pos[j][11]]):
										if(crash_pos[j][2] == -1):
											crash_pos[j][2] = i
										elif(crash_pos[j][3] == -1):
											crash_pos[j][3] = i
										elif(crash_pos[j][4] == -1):
											crash_pos[j][4] = i
										elif(crash_pos[j][5] == -1):
											crash_pos[j][5] = i
										elif(crash_pos[j][6] == -1):
											crash_pos[j][6] = i
										elif(crash_pos[j][7] == -1):
											crash_pos[j][7] = i
										elif(crash_pos[j][8] == -1):
											crash_pos[j][8] = i
										elif(crash_pos[j][9] == -1):
											crash_pos[j][9] = i
										elif(crash_pos[j][10] == -1):
											crash_pos[j][10] = i
										elif(crash_pos[j][11] == -1):
											crash_pos[j][11] = i
								elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
									crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
							elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
								crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
 
			#-------------------normal vehicles---------------
			for i in range(200):
				TmpPos = inputVehInfo (i, NewVeh);
					# set a array to store each vehicle's route info
				if (checkRoute[i] == -1):
					getRouteID[i] = traci.vehicle.getRouteID(str(i))
					checkRoute[i] = 1
					if(getRouteID[i] == "route0"):
						Route[i] = 0
					elif(getRouteID[i] == "route1"):
						Route[i] = 1
					elif(getRouteID[i] == "route2"):
						Route[i] = 2
					elif(getRouteID[i] == "route3"):
						Route[i] = 3
					elif(getRouteID[i] == "route4"):
						Route[i] = 4
					elif(getRouteID[i] == "route5"):
						Route[i] = 5	
					elif(getRouteID[i] == "route6"):
						Route[i] = 6
					elif(getRouteID[i] == "route7"):
						Route[i] = 7
					elif(getRouteID[i] == "route8"):
						Route[i] = 8
				#detect(10 meters) and verify
				if(TmpPos[0]!= -1 and TmpPos[0] < 7460):
					for j in range(int(TmpPos[0]) + 40,int(TmpPos[0]), -1):
						if(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh and crash_pos[j][12] == Route[i]):
							if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1): 
								#try to check if collusion team exists (parking = collustion team's state)
								if (traci.vehicle.getStopState(str(crash_pos[j][0])) == 7): #crash_pos[j][0] = Vehid, state = 7 means parking
									#print "i=",i,"finds collustion team j=",j
									#if warning exists
									if (warning[j][1] == 1 and warning[j][12] == Route[i]):	
										#check if itself already adds into warning									#check if itself already adds into warning
										if(i not in [warning[j][2],warning[j][3],warning[j][4],warning[j][5],warning[j][6],warning[j][7],warning[j][8],warning[j][9],warning[j][10],warning[j][11]]):
											if(warning[j][2] == -1):
												warning[j][2] = i
											elif(warning[j][3] == -1):
												warning[j][3] = i
											elif(warning[j][4] == -1):
												warning[j][4] = i
											elif(warning[j][5] == -1):
												warning[j][5] = i
											elif(warning[j][6] == -1):
												warning[j][6] = i
											elif(warning[j][7] == -1):
												warning[j][7] = i
											elif(warning[j][8] == -1):
												warning[j][8] = i
											elif(warning[j][9] == -1):
												warning[j][9] = i
											elif(warning[j][10] == -1):
												warning[j][10] = i
											elif(warning[j][11] == -1):
												warning[j][11] = i
										posCount[int(Route[i])] = countPos(j);
										negCount[int(Route[i])] = countNeg(j);
										#print "CancelChecking - posCount=",posCount,"negCount=",negCount,"i=",i,"j=",j
										
										if (negCount[int(Route[i])] >= posCount[int(Route[i])]):
											warning[j][1] = -1
											warning[j][12] = -1
											#if (changedRouteFirstBeneficary[0] == -1):	
											#	changedRouteFirstBeneficary[0] = i
											#print "CancelWarning - posCount=",posCount,"negCount=",negCount,"i=",i,"j=",j

				#receive warning(100 meters) and change route
				if(TmpPos[0] < 7100):
					MaxRange = int(TmpPos[0]) + 300
				else:
					MaxRange = 7499
				if(TmpPos[0]!= -1 and checkedRoute[i] == 0):#if changed route in previous step, omit this checking
				   for j in range(MaxRange,int(TmpPos[0]),-1):
						if(warning[j][1] == 1 and warning[j][12] == Route[i]):
							if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1):
								#print "ID", i,"warning received"
								r = 0
								if (ra[i] == 0):
									r = random.randint(0, 9)
									rr[i] = r
									ra[i] = 1
								else:
									r = rr[i]
								posCount[int(Route[i])] = countPos(j);
								negCount[int(Route[i])] = countNeg(j);
								#print "RouteChecking - posCount=",posCount,"negCount=",negCount,"i=",i,"j=",j								
								checkPercentage = 0
								if (trustMethod == "CDPD[0.7]"):
									checkPercentage = 0.7
								if (trustMethod == "CDPD[0.9]"):
									checkPercentage = 0.9
								if (r < 8 and float(posCount[int(Route[i])])/(posCount[int(Route[i])] + negCount[int(Route[i])]) > checkPercentage):
									changeRoute(i,r)
									#print "turned Vehicle ID:",i,float(posCount)/(posCount+negCount),"RRRR:",r

									
		step = step + 1
		
		#force end
		if(step == 550):
			break;
		LastVeh = NewVeh
	
	#output
	if(step == 550 or traci.simulation.getMinExpectedNumber() == 0):
		crashedV = 0
		changedRouteVictimCount = 0
		for v in range(200):
			if (crashedVeh[v] == 1):
				crashedV += 1
			if (changedRouteVictim[v] == 1):
				changedRouteVictimCount += 1		
		print "---- step: ",step,"crashedV =",crashedV,"firstVID =",firstVID[0],"crvc =",changedRouteVictimCount,"Route7 = ",changedRouteFirstBeneficary[7] + 1,"Route4 = ",changedRouteFirstBeneficary[4] + 1,"Route8 = ",changedRouteFirstBeneficary[8] + 1,"Route2 = ",changedRouteFirstBeneficary[2] + 1,"Route0 = ",changedRouteFirstBeneficary[0] + 1
	sys.stdout.flush()
	traci.close()


def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options

def inputVehInfo( i, NewVeh ):
	if(str(i) in NewVeh):
		speed[i] = traci.vehicle.getSpeed(str(i))
		position.insert(i,traci.vehicle.getPosition(str(i)))
		edge[i] = traci.vehicle.getRoadID(str(i))
	else:
		speed[i] = -1
		position.insert(i,[-1,-1])
		edge[i] = "-1"
	TmpPos = position[i]
	return TmpPos

def changeRoute(i,r):
	#print"TS[3] or TS[5] or TS[8]","Route[i]:",Route[i],"edge[i]:",edge[i]
	if (checkedRoute[i] == 0):
		if(edge[i] == "120245128#0"):
			traci.vehicle.setRoute(str(i),["120245128#0","5699451#1","5699451#2","5697601#0","5697601#1","5697601#2","420886650","420886652","420886649","420886648","274840500","274840501"])
			#print "ID = ",i,"i1 = ", traci.vehicle.getRoute(str(i))    
			checkedRoute[i] = 1
			changedRouteVictim[i] = 1
			changedRouteFirstBeneficary[int(Route[i])] = i
			if (firstVAppeared[0] == -1):
				firstVID[0] = i
				firstVAppeared[0] = 1	
			#print "Vehicle ID:",i,"on route:",Route[i]											
		if(edge[i] == "5699670#1"):
			traci.vehicle.setRoute(str(i),["5699670#1","275037810#3","275037810#4","5697769#2","420892588","420892360","420892370","420892356","420892367","420892036","420892034","420892363","420892041","420892037","420892039","420892040","420892035","5697974#3","5697974#4"])
			#print "ID = ",i,"i1 = ", traci.vehicle.getRoute(str(i))    
			checkedRoute[i] = 1
			changedRouteVictim[i] = 1
			changedRouteFirstBeneficary[int(Route[i])] = i
			if (firstVAppeared[0] == -1):
				firstVID[0] = i
				firstVAppeared[0] = 1	
			#print "Vehicle ID:",i,"on route:",Route[i]		
		if(edge[i] == "274840499"):
			traci.vehicle.setRoute(str(i),["274840499","275037810#9","275037810#10","275037810#11","275037810#12","120245128#3","420887604","420887588","420887593","420887597","420886651","420886650","420886652","420886649","420886648","274840500","274840501"])
			#print "ID = ",i,"i1 = ", traci.vehicle.getRoute(str(i))    
			checkedRoute[i] = 1
			changedRouteVictim[i] = 1
			changedRouteFirstBeneficary[int(Route[i])] = i
			if (firstVAppeared[0] == -1):
				firstVID[0] = i
				firstVAppeared[0] = 1	
			#print "Vehicle ID:",i,"on route:",Route[i]		
		if(edge[i] == "5697769#1"):
			traci.vehicle.setRoute(str(i),["5697769#1","275037810#5","275037810#6","5699334#1","420894325","420886015","420885645","420892587","420892588","420892360","420892370","420892356","420892367","420892036","420892034","420892363","420892041","420892037","420892039","420892040","420892035","5697974#3","5697974#4"])
			#print "ID = ",i,"i1 = ", traci.vehicle.getRoute(str(i))    
			checkedRoute[i] = 1
			changedRouteVictim[i] = 1
			changedRouteFirstBeneficary[int(Route[i])] = i
			if (firstVAppeared[0] == -1):
				firstVID[0] = i
				firstVAppeared[0] = 1	
			#print "Vehicle ID:",i,"on route:",Route[i]	
		if(edge[i] == "5697974#0"):
			traci.vehicle.setRoute(str(i),["5697974#0","-277135210#1","-277135210#0","5695597#0","5695597#1","5695597#2","225878899#1","225878899#2"])		
			#print "ID = ",i,"i1 = ", traci.vehicle.getRoute(str(i))    
			checkedRoute[i] = 1
			changedRouteVictim[i] = 1
			changedRouteFirstBeneficary[int(Route[i])] = i
			if (firstVAppeared[0] == -1):
				firstVID[0] = i
				firstVAppeared[0] = 1	
			#print "Vehicle ID:",i,"on route:",Route[i]		
	return

def countPos(j):
	posCount = 0
	for p in range(2,12):
		if (crash_pos[j][p] != -1):
			posCount += 1
	return posCount + 1	#+1 because crash_pos should count owner (which is always positive)

def countNeg(j):
	negCount = 0
	for p in range(2,12):
		if (warning[j][p] != -1):
			negCount += 1
	return negCount

# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()
	
	sumoBinary = checkBinary('sumo')
	sumoProcess = subprocess.Popen(["sumo", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	#if options.nogui:
	#   sumoBinary = checkBinary('sumo')
	#else:
	#    sumoBinary = checkBinary('sumo-gui')
	#sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	
	run()
	sumoProcess.wait()
