#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8816
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def generate_routefile():
	random.seed(46) # make tests reproducible
	N =  500 # number of time steps
	# demand per second from different directions
   
	with open("r46d160.xml", "w") as routes:
		print >> routes, """<routes>
	<vType accel="1.0" decel="5.0" id="Car" length="4.5" minGap="2.0" maxSpeed="60.0" sigma="0" />
	<route id="route0" edges="120245128#0 120245128#1 120245128#2 120245128#3 420887604 420887588 420887593 420887597 420886651 420886650 420886652 420886649 420886648 274840500 274840501" />
	<route id="route1" edges="5698817#0 5698817#1 5698817#2 275037810#1 275037810#2 275037810#3 275037810#4 275037810#5 275037810#6 275037810#7 275037810#8 275037810#9 275037810#10 275037810#11 275037810#12 275037810#13"/>
	<route id="route2" edges="120245127 274840502#0 274840502#1 274840499 274840498 274840500 274840501" />
	<route id="route3" edges="5698789#0 5698789#1 420887593 420887597 420886651 420886650 420886652 420886649 420886648 420886653 420894324 420894323 420886263 420894325 420886015 420885645 420892587 420892588 420892360 420892370 420892356 420892367 420892036 420892034 420892363 420892041 420892037 420892039 420892040 420892035 420892038 420885644 420885642 420885643 5695597#1 5695597#2 5695597#3"/>
	<route id="route4" edges="5697769#0 5697769#1 5697769#2 420892588 420892360 420892370 420892356 420892367 420892036 420892034 420892363 420892041 420892037 420892039 420892040 420892035 5697974#3 5697974#4" />
	<route id="route5" edges="-223860152#7 -223860152#6 -223860152#5 -223860152#4 -223860152#3 -223860152#2 -223860152#1 -223860152#0 -223860165#3 -223860165#2 -223860165#1 -223860165#0 -277135210#4 -277135210#3 -277135210#2 -277135210#1 -277135210#0 5695597#0 5695597#1 5695597#2 5695597#3"/>
	<route id="route6" edges="-120245128#5 -5699230#14 -5699230#13 -5699230#12 -5699230#11 -5699230#10 -5699230#9 -5699230#8 -5699230#7 -5699230#6 -5699230#5 -5699230#4 -5699230#3 -5699230#2 -5699230#1 -5699230#0"/>
	<route id="route7" edges="5697974#0 5697974#1 5697974#2 5697974#3 5697974#4"/>
	<route id="route8" edges="5699670#0 5699670#1 5699670#2 420892367 420892036 420892034 420892363 420892041 420892037 420892039 420892040 420892035 5697974#3 5697974#4"/>"""
		lastVeh = 0
		vehNr = 0
		for i in range(N):
			r = random.randint(0, 8)
			#if (vehNr == 0):
			#    print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
			#    print >> routes, '         <stop lane="3to1_0" endPos="50" duration="150"/>'
			#    print >> routes, '    </vehicle>'
			#    vehNr += 1
			#    lastVeh = i
			#    continue                
			if(vehNr == 0):
				print >> routes,'	<vehicle id="%i" type="Car" route="route0" depart="%i" departSpeed="random">' % (vehNr, i)
				print >> routes,'	<stop lane="120245128#1_0" endPos="160" duration="50"/>'
				print >> routes,'	</vehicle>'
				vehNr += 1
				lastVeh = i
				continue
			if(vehNr == 99):
				print >> routes,'	<vehicle id="%i" type="Car" route="route8" depart="%i" departSpeed="random">' % (vehNr, i)
				print >> routes,'	<stop lane="5699670#2_0" endPos="160" duration="50"/>'
				print >> routes,'	</vehicle>'
				vehNr += 1
				lastVeh = i
				continue
			if(vehNr == 199):
				print >> routes,'	<vehicle id="%i" type="Car" route="route8" depart="%i" departSpeed="random">' % (vehNr, i)
				print >> routes,'	<stop lane="274840498_0" endPos="160" duration="50"/>'
				print >> routes,'	</vehicle>'
				vehNr += 1
				lastVeh = i
				continue
			if(vehNr == 299):
				print >> routes,'	<vehicle id="%i" type="Car" route="route8" depart="%i" departSpeed="random">' % (vehNr, i)
				print >> routes,'	<stop lane="5697769#2_0" endPos="160" duration="50"/>'
				print >> routes,'	</vehicle>'
				vehNr += 1
				lastVeh = i
				continue            
			if(vehNr == 399):
				print >> routes,'	<vehicle id="%i" type="Car" route="route8" depart="%i" departSpeed="random">' % (vehNr, i)
				print >> routes,'	<stop lane="5697974#1_0" endPos="160" duration="50"/>'
				print >> routes,'	</vehicle>'
				vehNr += 1
				lastVeh = i
				continue            
			#if(vehNr != 0 and vehNr != 99 and vehNr != 199 and vehNr != 299 and vehNr != 399):
			if (r == 0):
				print >> routes, '    <vehicle id="%i" type="Car" route="route0" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 1):
				print >> routes, '    <vehicle id="%i" type="Car" route="route1" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 2):
				print >> routes, '    <vehicle id="%i" type="Car" route="route2" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 3):
				print >> routes, '    <vehicle id="%i" type="Car" route="route3" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 4):
				print >> routes, '    <vehicle id="%i" type="Car" route="route4" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 5):
				print >> routes, '    <vehicle id="%i" type="Car" route="route5" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 6):
				print >> routes, '    <vehicle id="%i" type="Car" route="route6" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 7):
				print >> routes, '    <vehicle id="%i" type="Car" route="route7" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
			if (r == 8):
				print >> routes, '    <vehicle id="%i" type="Car" route="route8" depart="%i" departSpeed="random"/>' % (vehNr, i)
				vehNr += 1
				lastVeh = i
		print >> routes, "</routes>"



def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options



# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()
	sumoBinary = checkBinary('sumo')
	sumoProcess = subprocess.Popen(["sumo", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	generate_routefile()
	sumoProcess.wait()
