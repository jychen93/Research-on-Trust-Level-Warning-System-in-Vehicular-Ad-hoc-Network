#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
getRouteID = []
Route = [0 for i in range(0,100)]
checkRoute = [0 for i in range(0,100)]
position = []
ra = [0 for i in range(0,100)]
rr = [0 for i in range(0,100)]
t = 0
#make the count++ happened only on the same route

checkedRoute = [0 for i in range(0,100)]
crashedVeh = [0 for i in range(0,100)]
# we need to import python modules from the $SUMO_HOME/tools directory
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
	#initialize variables
	step = 0
	LastVeh = []
	b = 0
	crashedV = 0
	firstVID = [0 for i in range(0,9)]
	firstVAppeared = [0 for i in range(0,9)]
 
	for i in range(7500):
		crash_pos.append([-1,0,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3,Route[i]]   3 verifier, 
		warning.append([-1,0,-1]) #[vehicle id, warning or not, Route[i]]

	for i in range(100):
		speed.append(-1)
		detected_flag.append(0)
		edge.append("-1")
		position.append([-1,-1])
		getRouteID.append("-1")


 #   """execute the TraCI control loop"""
	traci.init(PORT)

	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
		NewVeh = traci.vehicle.getIDList()
		DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
		ThreadNum = len(DecVeh)
		
		if (step == 274):
			print "---- step: ",step,"crashedV =",crashedV,"firstVID Route0 =",firstVID[0] + 1,"firstVID Route2 =",firstVID[2] + 1,"firstVID Route4 =",firstVID[4] + 1,"firstVID Route7 =",firstVID[7] + 1,"firstVID Route8 =",firstVID[8] + 1
		
		if(step >= 10):
			onetime = 0
			#print "step:",step,"str(i):",str(i) 
			#print "step:",step,"NewVeh:",NewVeh
			for i in range(100):
				# set a array to store each vehicle's route info
				if (checkRoute[i] == 0):
					getRouteID[i] = traci.vehicle.getRouteID(str(i))
					checkRoute[i] = 1
					if(getRouteID[i] == "route0"):
						Route[i] = 0
					elif(getRouteID[i] == "route1"):
						Route[i] = 1
					elif(getRouteID[i] == "route2"):
						Route[i] = 2
					elif(getRouteID[i] == "route3"):
						Route[i] = 3
					elif(getRouteID[i] == "route4"):
						Route[i] = 4
					elif(getRouteID[i] == "route5"):
						Route[i] = 5
					elif(getRouteID[i] == "route6"):
						Route[i] = 6
					elif(getRouteID[i] == "route7"):
						Route[i] = 7
					elif(getRouteID[i] == "route8"):
						Route[i] = 8
				if(str(i) in NewVeh):
					speed[i] = traci.vehicle.getSpeed(str(i))
					position.insert(i,traci.vehicle.getPosition(str(i)))
					edge[i] = traci.vehicle.getRoadID(str(i))
				else:
					speed[i] = -1
					position.insert(i,[-1,-1])
					edge[i] = "-1"
				TmpPos = position[i]

			#if a car is in an accident ,this defines its behavior
				if(speed[i] < 0.1 and TmpPos[0] > 10 and str(i) in NewVeh and i!= 0 and i!= 20 and i!= 40 and i!= 60 and i!= 80):
					if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1]):
						crash_pos[int(TmpPos[0])] = [i,1,-1,-1]
						crash_pos[int(TmpPos[0])][3] = Route[i]
						if(Route[i] == 0 or edge[i] == "120245128#1" or edge[i] == "5699670#2" or edge[i] == "274840498" or edge[i] == "5697769#2" or edge[i] == "5697974#1" or edge[i] == "120245128#0" or edge[i] == "5699670#1" or edge[i] == "274840499" or edge[i] == "5697769#1" or edge[i] == "5697974#0"):
							crashedVeh[i] = 1
					elif(crash_pos[int(TmpPos[0])][1] == 1 and crash_pos[int(TmpPos[0])][3] == Route[i] and crash_pos[int(TmpPos[0])][2] != -1):
						#print "verified,send warning"
						warning[int(TmpPos[0])] = [i,1,Route[i]]                    
				if(speed[i] < 0.1 and TmpPos[0] > 10 and i == 0 and i== 20 and i== 40 and i== 60 and i== 80):
					if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1]):
						crash_pos[int(TmpPos[0])] = [i,1,-1,-1]
						#crashedVeh[i] = 1;

			#detect(10 meters) and verify
				if(TmpPos[0]!= -1 and TmpPos[0] < 7460 and str(i) in NewVeh and i!= 0 and i!= 20 and i!= 40 and i!= 60 and i!= 80):
					for j in range(int(TmpPos[0]) + 40,int(TmpPos[0]),-1):
						if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
							crash_pos[j][1] = 1
							crash_pos[j][2] = i
							crash_pos[int(TmpPos[0])][3] = Route[i]
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh):
							if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1 ):
								#print i,"detected",crash_pos[j][0]
								#print"ab = ",ab                             
								if(i not in [crash_pos[j][2]] and crash_pos[int(TmpPos[0])][3] == Route[i]):
									if(crash_pos[j][2] == -1):
										crash_pos[j][2] = i
										#print i,"verified",crash_pos[j][0]                                 
										#print "Step",step,"Vehicle",i,"crash_pos[int(TmpPos[0])][5]",crash_pos[int(TmpPos[0])][5]
										if((Route[i] == 0 and i >= 0) or (Route[i] == 8 and i >= 20) or (Route[i] == 2 and i >= 40) or (Route[i] == 4 and i >= 60) or (Route[i] == 7 and i >= 80)):
											if(edge[i] == "120245128#0"):
												traci.vehicle.setRoute(str(i),["120245128#0","5699451#1","5699451#2","5697601#0","5697601#1","5697601#2","420886650","420886652","420886649","420886648","274840500","274840501"])
												checkedRoute[i] = 1
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											if(edge[i] == "5699670#0"):
												traci.vehicle.setRoute(str(i),["5699670#0","-223860165#0","-277135210#4","-277135210#3","-277135210#2","5697974#1","5697974#2","5697974#3","5697974#4"])
												checkedRoute[i] = 1
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											if(edge[i] == "274840499"):
												traci.vehicle.setRoute(str(i),["274840499","275037810#9","275037810#10","275037810#11","275037810#12","120245128#3","420887604","420887588","420887593","420887597","420886651","420886650","420886652","420886649","420886648","274840500","274840501"])
												checkedRoute[i] = 1
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											if(edge[i] == "5697769#1"):
												traci.vehicle.setRoute(str(i),["5697769#1","275037810#5","275037810#6","5699334#1","420894325","420886015","420885645","420892587","420892588","420892360","420892370","420892356","420892367","420892036","420892034","420892363","420892041","420892037","420892039","420892040","420892035","5697974#3","5697974#4"])
												checkedRoute[i] = 1
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											if(edge[i] == "5697974#0"):
												traci.vehicle.setRoute(str(i),["5697974#0","-277135210#1","-277135210#0","5695597#0","5695597#1","5695597#2","225878899#1","225878899#2"])
												checkedRoute[i] = 1
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												#print "~~detect~~", "Vehicle",i,"Route",Route[i]
							elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
								crash_pos[j] = [-1,0,-1,-1]
								warning[int(TmpPos[0])] = [-1,0,-1]
						
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
							crash_pos[j] = [-1,0,-1,-1]
							warning[int(TmpPos[0])] = [-1,0,-1]

			#receive warningy(100 meters) and verify   the range can be changed
				if (ra[i] == 0):
					r = random.randint(0, 9)
					rr[i] = r
					ra[i] = 1
				else:
					r = rr[i]

				if(TmpPos[0] < 7100):
					MaxRange = int(TmpPos[0])+400
				else:
					MaxRange = 7499
				if(TmpPos[0]!= -1 and checkedRoute[i]==0 and str(i) in NewVeh and i!= 0 and i!= 20 and i!= 40 and i!= 60 and i!= 80):#if changed route in previous step, omit this checking
					for j in range(MaxRange,int(TmpPos[0]),-1):
						if(warning[j][1] == 1 and warning[j][2] == Route[i] and str(warning[j][0]) in NewVeh):
							if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1):
								#print "ID", i,"warning received"
								if (r < 8 and ((Route[i] == 0 and i >= 0) or (Route[i] == 8 and i >= 20) or (Route[i] == 2 and i >= 40) or (Route[i] == 4 and i >= 60) or (Route[i] == 7 and i >= 80))):
									if(edge[i] == "120245128#0"):
										traci.vehicle.setRoute(str(i),["120245128#0","5699451#1","5699451#2","5697601#0","5697601#1","5697601#2","420886650","420886652","420886649","420886648","274840500","274840501"])
										checkedRoute[i] = 1
										if (firstVAppeared[int(Route[i])] == 0):
											firstVID[int(Route[i])] = i
											firstVAppeared[int(Route[i])] = 1
										#print "~~receive~~", "Vehicle",i,"Route",Route[i]
									if(edge[i] == "5699670#0"):
										traci.vehicle.setRoute(str(i),["5699670#0","-223860165#0","-277135210#4","-277135210#3","-277135210#2","5697974#1","5697974#2","5697974#3","5697974#4"])
										checkedRoute[i] = 1
										if (firstVAppeared[int(Route[i])] == 0):
											firstVID[int(Route[i])] = i
											firstVAppeared[int(Route[i])] = 1
										#print "~~receive~~", "Vehicle",i,"Route",Route[i]
									if(edge[i] == "274840499"):
										traci.vehicle.setRoute(str(i),["274840499","275037810#9","275037810#10","275037810#11","275037810#12","120245128#3","420887604","420887588","420887593","420887597","420886651","420886650","420886652","420886649","420886648","274840500","274840501"])
										checkedRoute[i] = 1
										if (firstVAppeared[int(Route[i])] == 0):
											firstVID[int(Route[i])] = i
											firstVAppeared[int(Route[i])] = 1
										#print "~~receive~~", "Vehicle",i,"Route",Route[i]
									if(edge[i] == "5697769#1"):
										traci.vehicle.setRoute(str(i),["5697769#1","275037810#5","275037810#6","5699334#1","420894325","420886015","420885645","420892587","420892588","420892360","420892370","420892356","420892367","420892036","420892034","420892363","420892041","420892037","420892039","420892040","420892035","5697974#3","5697974#4"])
										checkedRoute[i] = 1
										if (firstVAppeared[int(Route[i])] == 0):
											firstVID[int(Route[i])] = i
											firstVAppeared[int(Route[i])] = 1
										#print "~~receive~~", "Vehicle",i,"Route",Route[i]
									if(edge[i] == "5697974#0"):
										traci.vehicle.setRoute(str(i),["5697974#0","-277135210#1","-277135210#0","5695597#0","5695597#1","5695597#2","225878899#1","225878899#2"])
										checkedRoute[i] = 1
										if (firstVAppeared[int(Route[i])] == 0):
											firstVID[int(Route[i])] = i
											firstVAppeared[int(Route[i])] = 1
										#print "~~receive~~", "Vehicle",i,"Route",Route[i]
							elif(traci.vehicle.getSpeed(str(warning[j][0])) > 0.1):
								warning[j] = [-1,0,-1]
						elif(str(warning[j][0]) not in NewVeh):
							warning[j] = [-1,0,-1]
		
		step = step + 1
		crashedV = 0
		
		for v in range(100):
			if (crashedVeh[v] == 1):
				crashedV += 1
		
		if(step == 299):
			break;
		LastVeh = NewVeh
	sys.stdout.flush()
	traci.close()


def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options



# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()
	
	sumoBinary = checkBinary('sumo')
	sumoProcess = subprocess.Popen(["sumo", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	#if options.nogui:
	#   sumoBinary = checkBinary('sumo')
	#else:
	#    sumoBinary = checkBinary('sumo-gui')
	#sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)

	run()
	sumoProcess.wait()
