#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
position = []
Route = [-2 for i in range(0,5010)]
Threshold = [-1 for i in range(0,7500)]
checkRoute = [-1 for i in range(0,200)]
ra = [0 for i in range(0,5010)]
rr = [0 for i in range(0,5010)]
t = 0
firstVID=[-1 for i in range(0,9)]
firstVAppeared=[0 for i in range(0,9)]
checkedRoute = [0 for i in range(0,5010)]
getRouteID = []
crashedVeh = [0 for i in range(0,200)]
crash = [0 for i in range(0,6)]
collisionTeam = int(sys.argv[1]) #[0-10] only, min. 4-->TS[3], min. 6-->TS[5], min. 9-->TS[8]
#(TS[3],TS[5],TS[8],PTS[3,5,8])
trustMethod = "TS[8]"
changedRouteVictim = [0 for i in range(0,5010)]
changedRouteFirstBeneficary = [-1 for i in range(1)]
malicious = [-1 for i in range (0,5010)]
cancel = [-1 for i in range(0,9)]
onetime = [0 for i in range (0,200)]
testnum = [0 for i in range (0,9)]
countnumber = [0 for i in range (0,200)]

# we need to import python modules from the $SUMO_HOME/tools directory
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
	#initialize variables
	step = 0
	LastVeh = []
	b = 0
	crashedV=0
	changedRouteVictimCount = 0
	collisionteam = collisionTeam + 1
	for i in range(7500):#max 750 road position
		crash_pos.append([-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3,verifier4,verifier5,verifier6,verifier7,verifier8,verifier9,verifier10,Route[i]] 
		warning.append([-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]) #[VehID,state(0/1),vehDeductionIDx10]

	for i in range(5010):									#max 5500 vehicles
		speed.append(-1)
		detected_flag.append(0)
		edge.append("-1")
		position.append([-1,-1])
		getRouteID.append("-1")

	#"""execute the TraCI control loop"""
	traci.init(PORT)

	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
		NewVeh = traci.vehicle.getIDList()
		DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
		ThreadNum = len(DecVeh)
			#-------------------collision team---------------
		if (step == 0):
			for i in range(1000,1011):
				Route[i] = 0
				if(i != 1011 - collisionteam):
					traci.vehicle.setRoute(str(i),["5701670#0","5701670#1","264301521#0","264301522","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
					#print "Vehicle ID",i,"malicious user turns to the passway"
				if (i == 1011 - collisionteam):
					#collision team members goes parking, pos is shifted by 1 [flags 7= force parking, flag 0=stops on road]
					traci.vehicle.setStop(str(i),"264301521#1", pos=(40-(i-1000)), laneIndex = 0, duration=2**31 - 1, flags = 0, startPos=0, until=-1)
		if(step >= 10):
			#-------------------normal vehicles---------------
			for i in range(200):
				TmpPos = inputVehInfo (i, NewVeh);
					# set a array to store each vehicle's route info
				if (checkRoute[i] == -1):
					getRouteID[i] = traci.vehicle.getRouteID(str(i))
					checkRoute[i] = 1
					if(getRouteID[i] == "route0"):
						Route[i] = 0
					elif(getRouteID[i] == "route1"):
						Route[i] = 1
					elif(getRouteID[i] == "route2"):
						Route[i] = 2
					elif(getRouteID[i] == "route3"):
						Route[i] = 3
					elif(getRouteID[i] == "route4"):
						Route[i] = 4
					elif(getRouteID[i] == "route5"):
						Route[i] = 5	
					elif(getRouteID[i] == "route6"):
						Route[i] = 6
					elif(getRouteID[i] == "route7"):
						Route[i] = 7
					elif(getRouteID[i] == "route8"):
						Route[i] = 8
				if(step == 10 and onetime[i] == 0):
					l = 0
					l = testnum[int(Route[i])]
					l = l + 1
					testnum[int(Route[i])] = l
					countnumber[i] = testnum[int(Route[i])]
					onetime[i] = 1
				if(speed[i] < 0.1 and TmpPos[0] > 10 and str(i) in NewVeh and (edge[i] == "264301521#1" or edge[i] == "264301521#0" or edge[i] == "5701670#1")):
					if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]):
						crash_pos[int(TmpPos[0])] = [i,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
						crash_pos[int(TmpPos[0])][12] = Route[i]
						crashedVeh[i] = 1
						#print  "Step = ",step,"Vehicle",i,"cancel fake warning"
					if(countnumber[i] > collisionTeam and crash_pos[int(TmpPos[0])][12] == Route[i]):
						cancel[int(Route[i])] = i  
						#print "Vehicle ID",i,"cancel the fake warning "   
				if(TmpPos[0] != -1 and TmpPos[0] < 7460 and (edge[i] == "264301521#1" or edge[i] == "264301521#0" or edge[i] == "5701670#1") and cancel[int(Route[i])] != -1):
					for j in range(int(TmpPos[0]) + 40,int(TmpPos[0]),-1):
						#record j's place as crash point, let i be the 1st one finds it
						if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
							crash_pos[j][1] = 1
							crash_pos[j][2] = i     
							crash_pos[int(TmpPos[0])][12] =  Route[i]
							crashedVeh[i] = 1                           
						#if j's place is crash point 
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh):
							# if j is stopped
							if(traci.vehicle.getSpeed(str(crash_pos[j][0])) == 0 and crash_pos[j][12] == Route[i]):
								#it is valid, add itself (i) into one of the verifiers
								if(i not in [crash_pos[j][2],crash_pos[j][3],crash_pos[j][4],crash_pos[j][5],crash_pos[j][6],crash_pos[j][7],crash_pos[j][8],crash_pos[j][9],crash_pos[j][10],crash_pos[j][11]]):
									if(crash_pos[j][2] == -1):
										crash_pos[j][2] = i
										crashedVeh[i] = 1 
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][3] == -1):
										crash_pos[j][3] = i
										crashedVeh[i] = 1 
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][4] == -1):
										crash_pos[j][4] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][5] == -1):
										crash_pos[j][5] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][6] == -1):
										crash_pos[j][6] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][7] == -1):
										crash_pos[j][7] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][8] == -1):
										crash_pos[j][8] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][9] == -1):
										crash_pos[j][9] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][10] == -1):
										crash_pos[j][10] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
									elif(crash_pos[j][11] == -1):
										crash_pos[j][11] = i
										crashedVeh[i] = 1
										#print  "Step = ",step,"Vehicle ID",i
							elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
								crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
							crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]

				if(crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][12] == Route[i]):
					if ((trustMethod == "TS[3]" or trustMethod == "PTS[3,5,8]") and warning[int(TmpPos[0])][0] != i): 
						#print i, " verified,send warning - TS[3]"
						warning[int(TmpPos[0])][0] = i #record generator's VehID
						warning[int(TmpPos[0])][1] = 3 #turn state to valid (-1=invalid,0=normal,TS[3]=3, TS[5]=5, TS[8]=8)
						warning[int(TmpPos[0])][12] = Route[i]
				if(crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][5] != -1 and crash_pos[int(TmpPos[0])][6] != -1 and crash_pos[int(TmpPos[0])][12] == Route[i]):
					if ((trustMethod == "TS[5]" or trustMethod == "PTS[3,5,8]") and warning[int(TmpPos[0])][0] != i or (trustMethod == "PTS[3,5,8]" and warning[int(TmpPos[0])][0] == i and warning[int(TmpPos[0])][1] == 3)): 
						#print i, " verified,send warning - TS[5]"
						warning[int(TmpPos[0])][0] = i 
						warning[int(TmpPos[0])][1] = 5 
						warning[int(TmpPos[0])][12] =  Route[i]
				if(crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][5] != -1 and crash_pos[int(TmpPos[0])][6] != -1 and crash_pos[int(TmpPos[0])][7] != -1 and crash_pos[int(TmpPos[0])][8] != -1 and crash_pos[int(TmpPos[0])][9] != -1 and crash_pos[int(TmpPos[0])][12] == Route[i]):
					if ((trustMethod == "TS[8]" or trustMethod == "PTS[3,5,8]") and warning[int(TmpPos[0])][0] != i or (trustMethod == "PTS[3,5,8]" and warning[int(TmpPos[0])][0] == i and warning[int(TmpPos[0])][1] == 5)): 
						#print i, " verified,send warning - TS[8]"
						warning[int(TmpPos[0])][0] = i
						warning[int(TmpPos[0])][1] = 8
						warning[int(TmpPos[0])][12] =  Route[i]
				#receive warning(100 meters) and change route
				if(TmpPos[0] < 7100):
					MaxRange = int(TmpPos[0]) + 300
				else:
					MaxRange = 7499
				if(TmpPos[0]!= -1 and checkedRoute[i] == 0):#if changed route in previous step, omit this checking
				   for j in range(MaxRange,int(TmpPos[0]),-1):
					   if((((trustMethod == "TS[3]" or trustMethod == "PTS[3,5,8]") and warning[j][1] == 3) or ((trustMethod == "TS[5]" or trustMethod == "PTS[3,5,8]") and warning[j][1] == 5) or ((trustMethod == "TS[8]" or trustMethod == "PTS[3,5,8]") and warning[j][1] == 8)) and str(warning[j][0]) in NewVeh and warning[j][12] == Route[i]):#3 observe TS's warning
							if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1):
								#print "ID", i,"warning received"
								r = 0
								if (ra[i] == 0):
									r = random.randint(0, 9)
									rr[i] = r
									ra[i] = 1
								else:
									r = rr[i]
								if (trustMethod == "TS[3]" or trustMethod == "TS[5]" or trustMethod == "TS[8]"and (edge[i] == "264301521#0" or edge[i] == "5701670#1" or edge[i] == "5701670#0" )):
									if (r < 8):
										changeRoute(i,r)
									else:
										crashedVeh[i] = 1
										#print "Vehicle ID", i,"do not trust the warning"
								if (trustMethod == "PTS[3,5,8]" and (edge[i] == "264301521#0" or edge[i] == "5701670#1" or edge[i] == "5701670#0" )):
									if (r <= 3 and warning[j][1] == 3):
										changeRoute(i,r)
									elif(r > 3 and warning[j][1] == 3):
										crashedVeh[i] = 1
									if (r <= 5 and warning[j][1] == 5):
										changeRoute(i,r)
									elif(r > 5 and warning[j][1] == 5):
										crashedVeh[i] = 1
									if (r <= 8 and warning[j][1] == 8):
										changeRoute(i,r)
									elif(r > 8 and warning[j][1] == 8):
										crashedVeh[i] = 1
								
		step = step + 1		
		#force end
		if(step == 1200):
			break;
		LastVeh = NewVeh
	
	#output
	if(step == 1200 or traci.simulation.getMinExpectedNumber() == 0):
		crashedV = 0
		changedRouteVictimCount = 0
		for v in range(200):
			if (crashedVeh[v] == 1):
				crashedV += 1
			if (changedRouteVictim[v] == 1):
				changedRouteVictimCount += 1		
		print "---- step: ",step,"crashedV =",crashedV + collisionTeam,"firstVID[0] =",firstVID[0]
	sys.stdout.flush()
	traci.close()


def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action = "store_true", default = False, help = "run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options

def inputVehInfo( i, NewVeh ):
	if(str(i) in NewVeh):
		speed[i] = traci.vehicle.getSpeed(str(i))
		position.insert(i,traci.vehicle.getPosition(str(i)))
		edge[i] = traci.vehicle.getRoadID(str(i))
	else:
		speed[i] = -1
		position.insert(i,[-1,-1])
		edge[i] = "-1"
	TmpPos = position[i]
	return TmpPos

def changeRoute(i,r):
	#print"TS[3] or TS[5] or TS[8]","Route[i]:",Route[i],"edge[i]:",edge[i]
	if (checkedRoute[i] == 0):
		if(edge[i] == "264301521#0" and Route[i] == 0):
			traci.vehicle.setRoute(str(i),["264301521#0","264301522","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
			if (firstVAppeared[int(Route[i])] == 0):
				firstVID[int(Route[i])] = i
				firstVAppeared[int(Route[i])] = 1
			#print "~~detect~~", "Vehicle",i,"Route",Route[i]	
		if(edge[i] == "5701670#1" and Route[i] == 0):
			traci.vehicle.setRoute(str(i),["5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
			if (firstVAppeared[int(Route[i])] == 0):
				firstVID[int(Route[i])] = i
				firstVAppeared[int(Route[i])] = 1
			#print "~~detect~~", "Vehicle",i,"Route",Route[i]	
		if(edge[i] == "5701670#0" and Route[i] == 0):
			traci.vehicle.setRoute(str(i),["5701670#0","5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
			if (firstVAppeared[int(Route[i])] == 0):
				firstVID[int(Route[i])] = i
				firstVAppeared[int(Route[i])] = 1
			#print "~~detect~~", "Vehicle",i,"Route",Route[i]	
	return

# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()
	
	sumoBinary = checkBinary('sumo')
	sumoProcess = subprocess.Popen(["sumo", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	#if options.nogui:
	#   sumoBinary = checkBinary('sumo')
	#else:
	#	sumoBinary = checkBinary('sumo-gui')
	#sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	
	run()
	sumoProcess.wait()
