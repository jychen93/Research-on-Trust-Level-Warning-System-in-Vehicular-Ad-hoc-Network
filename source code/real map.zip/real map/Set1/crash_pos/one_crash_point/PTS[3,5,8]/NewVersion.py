#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
getRouteID = []
Route = [0 for i in range(0,200)]
checkRoute = [0 for i in range(0,200)]
position = []
ra = [0 for i in range(0,200)]
rr = [0 for i in range(0,200)]
t = 0
#make the count++ happened only on the same route

checkedRoute = [0 for i in range(0,200)]
crashedVeh = [0 for i in range(0,200)]
# we need to import python modules from the $SUMO_HOME/tools directory
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
	#initialize variables
	step = 0
	LastVeh = []
	b = 0
	crashedV = 0
	firstVID = [0 for i in range(0,9)]
	firstVAppeared = [0 for i in range(0,9)]
 
 
	for i in range(7500):
		crash_pos.append([-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3,verifier4,verifier5,Route[i]]   5 verifier, 
		warning.append([-1,0,-1]) #[vehicle id, warning or not, Route[i]]

	for i in range(200):
		speed.append(-1)
		detected_flag.append(0)
		edge.append("-1")
		position.append([-1,-1])
		getRouteID.append("-1")


 #   """execute the TraCI control loop"""
	traci.init(PORT)

	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
		NewVeh = traci.vehicle.getIDList()
		DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
		ThreadNum = len(DecVeh)
		
		if (step == 199):
			print "---- step: ",step,"crashedV =",crashedV,"firstVID Route0 =",firstVID[0]
		
		if(step >= 10):
			for i in range(200):
				# set a array to store each vehicle's route info
				if (checkRoute[i] == 0):
					getRouteID[i] = traci.vehicle.getRouteID(str(i))
					checkRoute[i] = 1
					if(getRouteID[i] == "route0"):
						Route[i] = 0
					elif(getRouteID[i] == "route1"):
						Route[i] = 1
					elif(getRouteID[i] == "route2"):
						Route[i] = 2
					elif(getRouteID[i] == "route3"):
						Route[i] = 3
					elif(getRouteID[i] == "route4"):
						Route[i] = 4
					elif(getRouteID[i] == "route5"):
						Route[i] = 5
					elif(getRouteID[i] == "route6"):
						Route[i] = 6
					elif(getRouteID[i] == "route7"):
						Route[i] = 7
					elif(getRouteID[i] == "route8"):
						Route[i] = 8
				if(str(i) in NewVeh):
					speed[i] = traci.vehicle.getSpeed(str(i))
					position.insert(i,traci.vehicle.getPosition(str(i)))
					edge[i] = traci.vehicle.getRoadID(str(i))
				else:
					speed[i] = -1
					position.insert(i,[-1,-1])
					edge[i] = "-1"
				TmpPos = position[i]

			#if a car is in an accident ,this defines its behavior
				if(speed[i] < 0.1 and TmpPos[0] > 10 and str(i) in NewVeh and i!= 0):
					if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1]):
						crash_pos[int(TmpPos[0])] = [i,1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
						crash_pos[int(TmpPos[0])][10] = Route[i]
						if(Route[i] == 0 and (edge[i] == "264301521#1" or edge[i] == "264301521#0" or edge[i] == "5701670#1" or edge[i] == "5701670#0")):
							crashedVeh[i] = 1
					if(crash_pos[int(TmpPos[0])][1] == 1 and crash_pos[int(TmpPos[0])][10] == Route[i] and crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][5] != -1 and crash_pos[int(TmpPos[0])][6] != -1 and crash_pos[int(TmpPos[0])][7] != -1 and crash_pos[int(TmpPos[0])][8] != -1 and crash_pos[int(TmpPos[0])][9] != -1):
					#print "verified,send warning_TS8"
						warning[int(TmpPos[0])] = [i,1,Route[i]]
						if (b < 8):
							b = 8 
					elif(crash_pos[int(TmpPos[0])][1] == 1 and crash_pos[int(TmpPos[0])][10] == Route[i] and crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1 and crash_pos[int(TmpPos[0])][5] != -1 and crash_pos[int(TmpPos[0])][6] != -1):
					#print "verified,send warning_TS5"
						warning[int(TmpPos[0])] = [i,1,Route[i]]
						if (b < 5):
							b = 5
					elif(crash_pos[int(TmpPos[0])][1] == 1 and crash_pos[int(TmpPos[0])][10] == Route[i] and crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1):
					#print "verified,send warning_TS3"
						warning[int(TmpPos[0])] = [i,1,Route[i]]
						if (b < 3):
							b = 3               

			#detect(10 meters) and verify
				if(TmpPos[0]!= -1 and TmpPos[0] < 7460 and str(i) in NewVeh and i!= 0):
					for j in range(int(TmpPos[0]) + 40,int(TmpPos[0]),-1):
						if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
							crash_pos[j][1] = 1
							crash_pos[j][2] = i
							crash_pos[int(TmpPos[0])][10] = Route[i]
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh):
							if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1 ):
								#print i,"detected",crash_pos[j][0]
								#print"ab = ",ab                             
								if(i not in [crash_pos[j][2],crash_pos[j][3],crash_pos[j][4],crash_pos[j][5],crash_pos[j][6],crash_pos[j][7],crash_pos[j][8],crash_pos[j][9]] and crash_pos[int(TmpPos[0])][10] == Route[i]):
									if(crash_pos[j][2] == -1):
										crash_pos[j][2] = i
										#print i,"verified",crash_pos[j][0]                                 
									elif(crash_pos[j][3] == -1):
										crash_pos[j][3] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][4] == -1):
										crash_pos[j][4] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][5] == -1):
										crash_pos[j][5] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][6] == -1):
										crash_pos[j][6] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][7] == -1):
										crash_pos[j][7] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][8] == -1):
										crash_pos[j][8] = i
										#print i,"verified",crash_pos[j][0]
									elif(crash_pos[j][9] == -1):
										crash_pos[j][9] = i
										#print i,"verified",crash_pos[j][0]
										#print "Step",step,"Vehicle",i,"crash_pos[int(TmpPos[0])][5]",crash_pos[int(TmpPos[0])][5]
										r = random.randint(0, 9)
										if ((b == 3 and r < 3) or (b == 5 and r < 5) or (b == 8 and r < 8)):
											#print "threshold:",b,"random value:",r
											if(edge[i] == "264301521#0"):
												traci.vehicle.setRoute(str(i),["264301521#0","264301522","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
												checkedRoute[i] = 1
												crashedVeh[i] = 0
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												elif(firstVID[int(Route[i])] > i):
													firstVID[int(Route[i])] = i
													#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											elif(edge[i] == "5701670#1"):
												traci.vehicle.setRoute(str(i),["5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
												checkedRoute[i] = 1
												crashedVeh[i] = 0
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												elif(firstVID[int(Route[i])] > i):
													firstVID[int(Route[i])] = i
													#print "~~detect~~", "Vehicle",i,"Route",Route[i]
											elif(edge[i] == "5701670#0"):
												traci.vehicle.setRoute(str(i),["5701670#0","5701670#1","5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
												checkedRoute[i] = 1
												crashedVeh[i] = 0
												if (firstVAppeared[int(Route[i])] == 0):
													firstVID[int(Route[i])] = i
													firstVAppeared[int(Route[i])] = 1
												elif(firstVID[int(Route[i])] > i):
													firstVID[int(Route[i])] = i
													#print "~~detect~~", "Vehicle",i,"Route",Route[i]
							elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
								crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1]
								warning[int(TmpPos[0])] = [-1,0,-1]
						
						elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
							crash_pos[j] = [-1,0,-1,-1,-1,-1,-1,-1,-1,-1,-1]
							warning[int(TmpPos[0])] = [-1,0,-1]

			#receive warningy(100 meters) and verify   the range can be changed
				if (ra[i] == 0):
					r = random.randint(0, 9)
					rr[i] = r
					ra[i] = 1
				else:
					r = rr[i]

				if(TmpPos[0] < 7100):
					MaxRange = int(TmpPos[0])+400
				else:
					MaxRange = 7499
				if(TmpPos[0]!= -1 and checkedRoute[i]==0 and str(i) in NewVeh and i!= 0):#if changed route in previous step, omit this checking
					for j in range(MaxRange,int(TmpPos[0]),-1):
						if(warning[j][1] == 1 and warning[j][2] == Route[i] and str(warning[j][0]) in NewVeh):
							if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1):
								#print "ID", i,"warning received"
								if ((b == 3 and r < 3) or (b == 5 and r < 5) or (b == 8 and r < 8)):
									if (r < 8):
										#print "threshold:",b,"random value:",r
										if(edge[i] == "264301521#0"):
											traci.vehicle.setRoute(str(i),["264301521#0","264301522","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
											checkedRoute[i] = 1
											if (firstVAppeared[int(Route[i])] == 0):
												firstVID[int(Route[i])] = i
												firstVAppeared[int(Route[i])] = 1
											elif(firstVID[int(Route[i])] > i):
												firstVID[int(Route[i])] = i
												#print "~~receive~~", "Vehicle",i,"Route",Route[i]
										elif(edge[i] == "5701670#1"):
											traci.vehicle.setRoute(str(i),["5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
											checkedRoute[i] = 1
											if (firstVAppeared[int(Route[i])] == 0):
												firstVID[int(Route[i])] = i
												firstVAppeared[int(Route[i])] = 1
											elif(firstVID[int(Route[i])] > i):
												firstVID[int(Route[i])] = i
												#print "~~receive~~", "Vehicle",i,"Route",Route[i]
										elif(edge[i] == "5701670#0"):
											traci.vehicle.setRoute(str(i),["5701670#0","5701670#1","5706544#0","5706544#1","5706544#2","5706544#3","5706544#4","200957800#0","200957800#1","200957800#2","200957800#3","200957800#4","200957800#5","-200957797","5706557#0","5706557#1","5706557#2","5706557#3","5706557#4","5706557#5","440861400","200957799","216933520#0","216933520#1"])
											checkedRoute[i] = 1
											if (firstVAppeared[int(Route[i])] == 0):
												firstVID[int(Route[i])] = i
												firstVAppeared[int(Route[i])] = 1
											elif(firstVID[int(Route[i])] > i):
												firstVID[int(Route[i])] = i
												#print "~~receive~~", "Vehicle",i,"Route",Route[i]
							elif(traci.vehicle.getSpeed(str(warning[j][0])) > 0.1):
								warning[j] = [-1,0,-1]
						elif(str(warning[j][0]) not in NewVeh):
							warning[j] = [-1,0,-1]
		
		step = step + 1
		crashedV = 0
		
		for v in range(200):
			if (crashedVeh[v] == 1):
				crashedV += 1
		
		if(step == 200):
			break;
		LastVeh = NewVeh
	sys.stdout.flush()
	traci.close()


def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options



# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()
	
	sumoBinary = checkBinary('sumo')
	sumoProcess = subprocess.Popen(["sumo", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	#if options.nogui:
	#   sumoBinary = checkBinary('sumo')
	#else:
	#	sumoBinary = checkBinary('sumo-gui')
	#sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)

	run()
	sumoProcess.wait()
