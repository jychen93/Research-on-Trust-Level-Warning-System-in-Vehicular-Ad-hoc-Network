#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8813
crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
position = []
ra = [0 for i in range(0,102)]
rr = [0 for i in range(0,102)]
t = 0
passway = 0
# we need to import python modules from the $SUMO_HOME/tools directory
try:
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
	sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
	from sumolib import checkBinary
except ImportError:
	sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
	#initialize variables
	step = 0
	LastVeh = []
	b = 0
	ab = 0
	for i in range(1000):
		crash_pos.append([-1,0,-1,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3]   3 verifier, 
		warning.append([-1,0])

	for i in range(101):
		speed.append(-1)
		detected_flag.append(0)
		edge.append("-1")
		position.append([-1,-1])


 #   """execute the TraCI control loop"""
	traci.init(PORT)

	while traci.simulation.getMinExpectedNumber() > 0:
		traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
		NewVeh = traci.vehicle.getIDList()
		DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
		ThreadNum = len(DecVeh)

		#!!!!!!!!!!!!!!!  detect warning????? 
		
		print "step: ",step 

		if(step >= 1):
			for i in range(101):
				if(str(i) in NewVeh):
					speed[i] = traci.vehicle.getSpeed(str(i))
					position.insert(i,traci.vehicle.getPosition(str(i)))
					edge[i] = traci.vehicle.getRoadID(str(i))
				else:
					speed[i] = -1
					position.insert(i,[-1,-1])
					edge[i] = "-1"
				TmpPos = position[i]
				if(1):
					if(speed[i] < 0.1 and TmpPos[0] > 10 and i!= 0):
						if(crash_pos[int(TmpPos[0])] == [-1,0,-1,-1,-1]):
							crash_pos[int(TmpPos[0])] = [i,1,-1,-1,-1]
							#print i,"crash at road [3 to 1] ",TmpPos
							ab = ab + 1

						elif(crash_pos[int(TmpPos[0])][2] != -1 and crash_pos[int(TmpPos[0])][3] != -1 and crash_pos[int(TmpPos[0])][4] != -1):
							#print "verified,send warning"
							warning[int(TmpPos[0])] = [i,1]
							crash = 1
				
						#if(speed[i] < 0.1 and TmpPos[0] > 10 and i == 0 ):
							#print i,"crash generator",TmpPos
						#if(speed[i] < 0.1 and TmpPos[0] > 10 and i == 20 ):
							#print i,"crash generator",TmpPos

					if(TmpPos[0]!= -1 and TmpPos[0] < 300 and i!= 0):
						for j in range(int(TmpPos[0]) + 699,int(TmpPos[0]),-1):
							if(crash_pos[j][1] == 0 and str(crash_pos[j][0]) in NewVeh):
								crash_pos[j][1] = 1
								crash_pos[j][2] = i                                        
						
							elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) in NewVeh):
								if(traci.vehicle.getSpeed(str(crash_pos[j][0])) < 0.1 ):
									if(i not in [crash_pos[j][2],crash_pos[j][3],crash_pos[j][4]]):
										if(crash_pos[j][2] == -1):
											crash_pos[j][2] = i
											print i,"verified",crash_pos[j][0]
										elif(crash_pos[j][3] == -1):
											crash_pos[j][3] = i
											print i,"verified",crash_pos[j][0]
										elif(crash_pos[j][4] == -1):
											crash_pos[j][4] = i
											print i,"verified",crash_pos[j][0]
											r = random.randint(0, 9)
											if (r < 8):
												if(edge[i] == "2to8"):
													passway = random.randint(0, 2) 
													if(passway == 0):
														traci.vehicle.setRoute(str(i),["2to8","8to6","6to4","4to1"])
														print traci.vehicle.getRoute(str(i))
														#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
														#print"abababababababababababababababababababababa",ab
													elif(passway == 2):
														traci.vehicle.setRoute(str(i),["2to8","8to6","6to3","3to9","9to4","4to1"])
														print traci.vehicle.getRoute(str(i))
														#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
														#print"abababababababababababababababababababababa",ab
												elif(edge[i] == "6to3"):
													traci.vehicle.setRoute(str(i),["6to3","3to9","9to4","4to1"])
													print traci.vehicle.getRoute(str(i))
													#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
													#print"abababababababababababababababababababababa",ab
												elif(edge[i] == "3to9"):
													traci.vehicle.setRoute(str(i),["3to9","9to4","4to1"])
													print traci.vehicle.getRoute(str(i))
													#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
													#print"abababababababababababababababababababababa",ab
												
								elif(traci.vehicle.getSpeed(str(crash_pos[j][0])) > 0.1):
									crash_pos[j] = [-1,0,-1,-1,-1]
						
							elif(crash_pos[j][1] == 1 and str(crash_pos[j][0]) not in NewVeh):
								crash_pos[j] = [-1,0,-1,-1,-1]

					if (ra[i] == 0):
						r = random.randint(0, 9)
						rr[i] = r
						ra[i] = 1
					else:
						r = rr[i]

					if(TmpPos[0] < 250):
						MaxRange = int(TmpPos[0]) + 749
					else:
						MaxRange = 999
					if(TmpPos[0]!= -1 and i!= 0):
						for j in range(MaxRange,int(TmpPos[0]),-1):
							if(warning[j][1] == 1 and str(warning[j][0]) in NewVeh):
								if(traci.vehicle.getSpeed(str(warning[j][0])) < 0.1):
									print i,"warning received"
									if (r < 8): 
										print"fihaosoishdfadfaoidsjf[a",edge[i]
										if(edge[i] == "2to8"):
											passway = random.randint(0, 2) 
											if(passway == 0):
												traci.vehicle.setRoute(str(i),["2to8","8to6","6to4","4to1"])
												print traci.vehicle.getRoute(str(i))
												#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
												#print"abababababababababababababababababababababa",ab
											elif(passway == 2):
												traci.vehicle.setRoute(str(i),["2to8","8to6","6to3","3to9","9to4","4to1"])
												print traci.vehicle.getRoute(str(i))
												#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
												#print"abababababababababababababababababababababa",ab
										elif(edge[i] == "6to3"):
											traci.vehicle.setRoute(str(i),["6to3","3to9","9to4","4to1"])
											print traci.vehicle.getRoute(str(i))
											#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
											#print"abababababababababababababababababababababa",ab
										elif(edge[i] == "3to9"):
											traci.vehicle.setRoute(str(i),["3to9","9to4","4to1"])
											print traci.vehicle.getRoute(str(i))
											#print"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",i
											#print"abababababababababababababababababababababa",ab
								
								elif(traci.vehicle.getSpeed(str(warning[j][0])) > 0.1):
									warning[j] = [-1,0]
							elif(str(warning[j][0]) not in NewVeh):
								warning[j] = [-1,0]

		step = step + 1

		if(step == 800):
			break;
		LastVeh = NewVeh
	
	sys.stdout.flush()
	traci.close()


def get_options():
	optParser = optparse.OptionParser()
	optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
	options, args = optParser.parse_args()
	return options



# this is the main entry point of this script
if __name__ == "__main__":
	options = get_options()

	if options.nogui:
		sumoBinary = checkBinary('sumo')
	else:
		sumoBinary = checkBinary('sumo-gui')
	sumoProcess = subprocess.Popen(["sumo-gui", "-c", "complex.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
	run()
	sumoProcess.wait()
