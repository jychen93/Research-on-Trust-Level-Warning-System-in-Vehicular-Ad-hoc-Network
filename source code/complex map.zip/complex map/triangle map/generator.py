#!/usr/bin/env python

import os, sys
import optparse
import subprocess
import random
import threading
import time
import math

# the port used for communicating with your sumo instance
PORT = 8873

crash_pos = []
warning = []
speed = []
detected_flag = []
edge = []
position = []

# we need to import python modules from the $SUMO_HOME/tools directory
try:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', "tools")) # tutorial in tests
    sys.path.append(os.path.join(os.environ.get("SUMO_HOME", os.path.join(os.path.dirname(__file__), "..", "..", "..")), "tools")) # tutorial in docs
    from sumolib import checkBinary
except ImportError:
    sys.exit("please declare environment variable 'SUMO_HOME' as the root directory of your sumo installation (it should contain folders 'bin', 'tools' and 'docs')")

import traci

def run():
    #initialize variables
    step = 0
    LastVeh = []

    for i in range(750):
        crash_pos.append([-1,0,-1,-1,-1])    #[vehid,0:no crash 1:crash,verifier1,verifier2,verifier3]   3 verifier, 
        warning.append([-1,0])

    for i in range(90):
        speed.append(-1)
        detected_flag.append(0)
        edge.append("-1")
        position.append([-1,-1])


    """execute the TraCI control loop"""
    traci.init(PORT)

    while traci.simulation.getMinExpectedNumber() > 0:
        traci.simulationStep()                      # 204 steps in total , attention  when stepNum are changed so do speed message num
        NewVeh = traci.vehicle.getIDList()
        DecVeh = list(set(NewVeh).difference(set(LastVeh))) 
        ThreadNum = len(DecVeh)

        #!!!!!!!!!!!!!!!  detect warning????? 
        
        print "step: ",step 

        if(step >= 50):
            for i in range(90):
                if(str(i) in NewVeh):
                    speed[i] = traci.vehicle.getSpeed(str(i))
                    position.insert(i,traci.vehicle.getPosition(str(i)))
                    edge[i] = traci.vehicle.getRoadID(str(i))
                else:
                    speed[i] = -1
                    position.insert(i,[-1,-1])
                    edge[i] = "-1"
                TmpPos = position[i]
    
            step += 1
	if(step == 150):
	    break;
	LastVeh = NewVeh
  
    sys.stdout.flush()
    traci.close()


#some questions!  ... there will always be 3 cars stamed . and how many car is depended on xxxxxx



def generate_routefile():
    random.seed(50) # make tests reproducible
    N =  100 # number of time steps
    # demand per second from different directions
   
    with open("complex.rou.xml", "w") as routes:
        print >> routes, """<routes>
  	<vType accel="1.0" decel="5.0" id="Car" length="4.5" minGap="2.0" maxSpeed="50.0" sigma="0" />

    <route id="route0" edges="2to3 3to1" />
  	<route id="route1" edges="2to8 8to6 6to4 4to1" />
    <route id="route2" edges="2to8 8to6 6to3 3to1" />
    <route id="route3" edges="2to3 3to9 9to4 4to1" />
    <route id="route4" edges="2to8 8to6 6to3 3to9 9to4 4to1" />"""
        lastVeh = 0
        vehNr = 0
        for i in range(N):
            r = random.randint(0, 4)
            if (vehNr == 0):
                print >> routes, '    <vehicle depart="%i" id="%i" route="route0" type="Car" departPos="0" departSpeed="random">' % (i, vehNr)
                print >> routes, '         <stop lane="3to1_0" endPos="50" duration="150"/>'
                print >> routes, '    </vehicle>'
                vehNr += 1
                lastVeh = i
                continue                
            if (r == 0):
                print >> routes, '    <vehicle id="%i" type="Car" route="route0" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
            if (r == 1):
                print >> routes, '    <vehicle id="%i" type="Car" route="route1" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
            if (r == 2):
                print >> routes, '    <vehicle id="%i" type="Car" route="route2" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
            if (r == 3):
                print >> routes, '    <vehicle id="%i" type="Car" route="route3" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
            if (r == 4):
                print >> routes, '    <vehicle id="%i" type="Car" route="route4" depart="%i" />' % (vehNr, i)
                vehNr += 1
                lastVeh = i
        print >> routes, "</routes>"



def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true", default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options



# this is the main entry point of this script
if __name__ == "__main__":
    options = get_options()

    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')
    generate_routefile()

    sumoProcess = subprocess.Popen(["sumo-gui", "-c", "hello.sumocfg", "--tripinfo-output", "tripinfo.xml", "--remote-port", str(PORT)], stdout=sys.stdout, stderr=sys.stderr)
    run()
    sumoProcess.wait()
